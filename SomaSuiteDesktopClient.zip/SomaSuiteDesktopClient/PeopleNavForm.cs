﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomaSuiteDesktopClient
{
    public partial class PeopleNavForm : Form
    {
        public PeopleNavForm()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();

            NewStaffForm staffForm = new NewStaffForm();
            staffForm.ShowDialog();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            NewStudentForm newStudent = new NewStudentForm();
            newStudent.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
            NewGuardianForm newGuardian = new NewGuardianForm();
            newGuardian.ShowDialog();
        }
    }
}
