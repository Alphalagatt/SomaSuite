﻿using SomaSuiteDesktopClient.Conts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SomaSuiteDesktopClient.Models;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;

namespace SomaSuiteDesktopClient
{
    public partial class NewStaffForm : Form
    {
        public NewStaffForm()
        {
            InitializeComponent();

            
        }

        static HttpClient client = new HttpClient();





        /// <summary>
        /// this button crates the Staff Entity
        /// </summary>
        

        private void button2_Click(object sender, EventArgs e)
        {

            


            if (textBox1.Text == null)
            {
                MessageBox.Show("Please Enter the StaffID");
                textBox1.Focus();
            }
                
            else if (textBox2.Text == null || textBox2.Text == "")
            {
                MessageBox.Show("Please Enter the Staffs Full Names");
                textBox2.Focus();
            }
                
            else if (textBox3.Text == null || textBox3.Text == "")
            {
                MessageBox.Show("Please Enter Staffs NationalID number");
                textBox3.Focus();
            }
                

            else if (textBox1.Text!=null||textBox1.Text!=""&& textBox2.Text != null || textBox2.Text != "" && textBox3.Text != null || textBox3.Text != "")
            {
                
                    //submit staff data
                    Staff myStaff = new Staff();
                    myStaff.StaffID = textBox1.Text;
                    myStaff.FullName = textBox2.Text;
                    myStaff.NationalIDNo = textBox3.Text;
                    myStaff.Photo = "";



                    RunAsync(myStaff).GetAwaiter();
                    MessageBox.Show("Staff Successfully Created!!");

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
          
            }
            else
            {
                MessageBox.Show("We were unable to add that data to the database. Please check the contents and submit.");
            }
            

            
            

        }






        //create Staff Action..


        static async Task CreateProductAsync(Staff staff)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync("api/Staff", staff);
            response.EnsureSuccessStatusCode();

            // return URI of the created resource.
            //return response.Headers.Location;
        }





        static async Task RunAsync(Staff staff)
        {
            // Update port # in the following line.
            client.BaseAddress = new Uri("https://localhost:44312/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                
                await CreateProductAsync(staff);
                
            }
            catch (Exception e)
            {
                MessageBox.Show($"Something Went Wrong Please Check the Error!! {e.Message}");
            }

            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }


        // For displaying Roles available to the staff

        async Task<List<Role>> DisplayRoles(string url,HttpClient client)
        {
            List<Role> roles = new List<Role>();

            var myjson = await client.GetStringAsync(url);

            roles = JsonConvert.DeserializeObject<List<Role>>(myjson);

            return roles;

        }

        private async void NewStaffForm_Load(object sender, EventArgs e)
        {
            var myRoles = await DisplayRoles("https://localhost:44312/api/Role", client);
            
            foreach(Role role in myRoles)
            {
                roleBindingSource.Add(role);
            }
        }


        //get clicked row value

        






        // Assign roles to staff

        private void button1_Click(object sender, EventArgs e)
        {
            int numOfRows = 0;
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {

                bool isSelected = Convert.ToBoolean(dataGridView1.Rows[i].Cells[0].Value);
                if (isSelected)
                {
                    addRelationship(int.Parse(dataGridView1.Rows[i].Cells[1].Value.ToString()),textBox1.Text,client, "https://localhost:44312/api/addstaffrole");
                    numOfRows += 1;
                }


            }

            MessageBox.Show(numOfRows + " Rows Deleted");
        }


        //method to add relationship

        static async void addRelationship(int RoleId,string StaffId,HttpClient client,string url)
        {
            RoleStaff roleStaff = new RoleStaff();
            roleStaff.RolesRoleId = RoleId;
            roleStaff.StaffsStaffId = StaffId;

            await client.PostAsJsonAsync(url, roleStaff);


        }
    }
}
