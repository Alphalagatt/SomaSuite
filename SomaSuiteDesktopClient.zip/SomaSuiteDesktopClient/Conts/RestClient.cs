﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SomaSuiteDesktopClient.Conts
{
    class RestClient
    {
        public string EndPoint { get; set; }
        public string Method { get; set; }

        public string MakeRequest()
        {

            var request = WebRequest.Create(EndPoint) as WebRequest;



            request.Method = Method;
            var stream = new StreamReader(request.GetResponse().GetResponseStream());

            var result = stream.ReadToEnd();
            return result;

        }

        public void MakePostRequest(string postJSON)
        {
            var request = WebRequest.Create(EndPoint) as WebRequest;

            request.Method = Method;
            request.ContentType = "application/json"; //Really Important
            using (StreamWriter swJSONPayload = new StreamWriter(request.GetRequestStream()))
            {
                swJSONPayload.Write(postJSON);
                swJSONPayload.Close();
            }
        }



    }
    
}
