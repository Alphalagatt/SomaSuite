﻿using SomaSuiteDesktopClient.Conts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SomaSuiteDesktopClient.Models;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace SomaSuiteDesktopClient
{
    public partial class AllStaff : Form
    {
        public AllStaff()
        {
            InitializeComponent();
        }
        List<Staff> myTable = new List<Staff>();

        static HttpClient client = new HttpClient();


        private void AllStaff_Load(object sender, EventArgs e)
        {

                try
                {
                    var client = new RestClient() { EndPoint = "https://localhost:44312/api/Staff", Method = "Get" };
                    var result = client.MakeRequest();

                    List<Staff> Staffs = new List<Staff>();

                    Staffs = JsonConvert.DeserializeObject<List<Staff>>(result);


                    foreach (Staff myStaff in Staffs)
                    {
                        //myTable.Add(myStaff);
                        //dataGridView1.Rows.Add(myStaff.Photo,myStaff.StaffID, myStaff.FullName, myStaff.NationalIDNo);
                        staffBindingSource.Add(myStaff);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection Could not be established. Please check your internet connection. \n" + ex);
                }
            

        }


        //delete staff event
        private void button1_Click(object sender, EventArgs e)
        {
            int numOfRows = 0;
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                
                bool isSelected = Convert.ToBoolean(dataGridView1.Rows[i].Cells[0].Value);
                if (isSelected)
                {
                    RunAsync(dataGridView1.Rows[i].Cells[1].Value.ToString()).GetAwaiter();
                    numOfRows += 1;
                }

                
            }

            MessageBox.Show(numOfRows + " Rows Deleted");
        }

        //view staff event
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "ViewDetails")
            {
                var id = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                ViewStaff viewStaff = new ViewStaff(id);
                viewStaff.ShowDialog();

            }


        }



        //deleting staff
        #region deleteStaff
        static async Task DeleteProductAsync(string id)
        {
            HttpResponseMessage response = await client.DeleteAsync(
                $"api/Staff/{id}");
            //return response.StatusCode;
        }



        static async Task RunAsync(string id)
        {
            // Update port # in the following line.
            client.BaseAddress = new Uri("https://localhost:44312/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {

                // Delete the product
                 await DeleteProductAsync(id);


            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }



            #endregion
            


        }

        public static void getStaff()
        {
            try
            {
                var client = new RestClient() { EndPoint = "https://localhost:44312/api/Staff", Method = "Get" };
                var result = client.MakeRequest();

                List<Staff> Staffs = new List<Staff>();

                Staffs = JsonConvert.DeserializeObject<List<Staff>>(result);


                foreach (Staff myStaff in Staffs)
                {
                    //myTable.Add(myStaff);
                    //dataGridView1.Rows.Add(myStaff.Photo,myStaff.StaffID, myStaff.FullName, myStaff.NationalIDNo);
                    // staffBindingSource.Add(myStaff);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Could not be established. Please check your internet connection. \n" + ex);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
