﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomaSuiteDesktopClient
{
    public partial class StudentAccountForm : Form
    {
        public StudentAccountForm()
        {
            InitializeComponent();
        }

        private void StudentAccountForm_Load(object sender, EventArgs e)
        {
            label4.Text = DateTime.Now.ToString() + " - " + DateTime.Now.AddMonths(1).ToString();
        }
    }
}
