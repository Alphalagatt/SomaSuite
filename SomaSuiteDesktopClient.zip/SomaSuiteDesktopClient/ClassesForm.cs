﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomaSuiteDesktopClient
{
    public partial class ClassesForm : Form
    {
        public ClassesForm()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ClassPosition classPosition = new ClassPosition();
            classPosition.ShowDialog();

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Streams streams = new Streams();
            streams.ShowDialog();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = comboBox1.SelectedItem +DateTime.Today.Year.ToString();
            label8.Text = comboBox1.SelectedItem.ToString();
            label6.Text = comboBox1.SelectedItem.ToString() + DateTime.Today.Year.ToString();
        }

        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            foreach(string SelectedItem in checkedListBox1.CheckedItems)
            {
                listBox1.Items.Add(checkedListBox1.CheckedItems.ToString());
            }

            
        }
    }
}
