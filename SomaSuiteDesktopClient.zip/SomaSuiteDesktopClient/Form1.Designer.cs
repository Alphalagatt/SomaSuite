﻿namespace SomaSuiteDesktopClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Students = new System.Windows.Forms.MenuStrip();
            this.AddStudent = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewStudentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uploadStudentListsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewAllStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.addParentGuardianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.assignParentGuardianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllParentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applyFiltersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentAdmissionNumbersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nationalIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UploadStudentList = new System.Windows.Forms.ToolStripMenuItem();
            this.addClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllClassesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.staffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewStaffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllStaffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rolesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewRoleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewRolesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.makeNewFeePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seeAllPaymentRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkStudentPaymentStatementRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.checkStudentAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPaymentStatementsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.assignStructuresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewFeeStructureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateExistingStructuresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPaymentRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankSlipsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mpesaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cashToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPhysicalDeliveryRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPaymentByClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkBalancesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allFeeBalancesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.physicalDeliveryBalancesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkForPayrollToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewTransportRoutesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewListOfTransportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byClassToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.byRouteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.physicalStructuresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addPhysicalStructureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPhysucalStructuresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.assignToStudentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.IncomingInfo = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.label23 = new System.Windows.Forms.Label();
            this.Students.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.IncomingInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.SuspendLayout();
            // 
            // Students
            // 
            this.Students.Dock = System.Windows.Forms.DockStyle.None;
            this.Students.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Students.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Students.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddStudent,
            this.ViewAllStudents,
            this.UploadStudentList,
            this.staffToolStripMenuItem,
            this.rolesToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.recordsToolStripMenuItem,
            this.transportToolStripMenuItem,
            this.physicalStructuresToolStripMenuItem,
            this.logOutToolStripMenuItem});
            this.Students.Location = new System.Drawing.Point(180, 122);
            this.Students.Name = "Students";
            this.Students.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.Students.Size = new System.Drawing.Size(1618, 36);
            this.Students.TabIndex = 3;
            this.Students.Text = "Students";
            // 
            // AddStudent
            // 
            this.AddStudent.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudentToolStripMenuItem,
            this.viewStudentsToolStripMenuItem,
            this.uploadStudentListsToolStripMenuItem});
            this.AddStudent.Name = "AddStudent";
            this.AddStudent.Size = new System.Drawing.Size(102, 32);
            this.AddStudent.Text = "Students";
            // 
            // addStudentToolStripMenuItem
            // 
            this.addStudentToolStripMenuItem.Name = "addStudentToolStripMenuItem";
            this.addStudentToolStripMenuItem.Size = new System.Drawing.Size(278, 32);
            this.addStudentToolStripMenuItem.Text = "Add Student";
            // 
            // viewStudentsToolStripMenuItem
            // 
            this.viewStudentsToolStripMenuItem.Name = "viewStudentsToolStripMenuItem";
            this.viewStudentsToolStripMenuItem.Size = new System.Drawing.Size(278, 32);
            this.viewStudentsToolStripMenuItem.Text = "View Students";
            // 
            // uploadStudentListsToolStripMenuItem
            // 
            this.uploadStudentListsToolStripMenuItem.Name = "uploadStudentListsToolStripMenuItem";
            this.uploadStudentListsToolStripMenuItem.Size = new System.Drawing.Size(278, 32);
            this.uploadStudentListsToolStripMenuItem.Text = "Upload Student Lists";
            // 
            // ViewAllStudents
            // 
            this.ViewAllStudents.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addParentGuardianToolStripMenuItem,
            this.assignParentGuardianToolStripMenuItem,
            this.viewAllParentsToolStripMenuItem,
            this.applyFiltersToolStripMenuItem});
            this.ViewAllStudents.Name = "ViewAllStudents";
            this.ViewAllStudents.Size = new System.Drawing.Size(185, 32);
            this.ViewAllStudents.Text = "Parents/Guardians";
            // 
            // addParentGuardianToolStripMenuItem
            // 
            this.addParentGuardianToolStripMenuItem.Name = "addParentGuardianToolStripMenuItem";
            this.addParentGuardianToolStripMenuItem.Size = new System.Drawing.Size(303, 32);
            this.addParentGuardianToolStripMenuItem.Text = "Add Parent/Guardian";
            // 
            // assignParentGuardianToolStripMenuItem
            // 
            this.assignParentGuardianToolStripMenuItem.Name = "assignParentGuardianToolStripMenuItem";
            this.assignParentGuardianToolStripMenuItem.Size = new System.Drawing.Size(303, 32);
            this.assignParentGuardianToolStripMenuItem.Text = "Assign Parent/Guardian";
            // 
            // viewAllParentsToolStripMenuItem
            // 
            this.viewAllParentsToolStripMenuItem.Name = "viewAllParentsToolStripMenuItem";
            this.viewAllParentsToolStripMenuItem.Size = new System.Drawing.Size(303, 32);
            this.viewAllParentsToolStripMenuItem.Text = "View All Parents";
            // 
            // applyFiltersToolStripMenuItem
            // 
            this.applyFiltersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nameToolStripMenuItem,
            this.studentAdmissionNumbersToolStripMenuItem,
            this.nationalIDToolStripMenuItem,
            this.classToolStripMenuItem});
            this.applyFiltersToolStripMenuItem.Name = "applyFiltersToolStripMenuItem";
            this.applyFiltersToolStripMenuItem.Size = new System.Drawing.Size(303, 32);
            this.applyFiltersToolStripMenuItem.Text = "Apply Filters";
            // 
            // nameToolStripMenuItem
            // 
            this.nameToolStripMenuItem.Name = "nameToolStripMenuItem";
            this.nameToolStripMenuItem.Size = new System.Drawing.Size(347, 32);
            this.nameToolStripMenuItem.Text = "Name";
            // 
            // studentAdmissionNumbersToolStripMenuItem
            // 
            this.studentAdmissionNumbersToolStripMenuItem.Name = "studentAdmissionNumbersToolStripMenuItem";
            this.studentAdmissionNumbersToolStripMenuItem.Size = new System.Drawing.Size(347, 32);
            this.studentAdmissionNumbersToolStripMenuItem.Text = "Student Admission Numbers";
            // 
            // nationalIDToolStripMenuItem
            // 
            this.nationalIDToolStripMenuItem.Name = "nationalIDToolStripMenuItem";
            this.nationalIDToolStripMenuItem.Size = new System.Drawing.Size(347, 32);
            this.nationalIDToolStripMenuItem.Text = "National ID";
            // 
            // classToolStripMenuItem
            // 
            this.classToolStripMenuItem.Name = "classToolStripMenuItem";
            this.classToolStripMenuItem.Size = new System.Drawing.Size(347, 32);
            this.classToolStripMenuItem.Text = "Class";
            // 
            // UploadStudentList
            // 
            this.UploadStudentList.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addClassToolStripMenuItem,
            this.viewAllClassesToolStripMenuItem});
            this.UploadStudentList.Name = "UploadStudentList";
            this.UploadStudentList.Size = new System.Drawing.Size(87, 32);
            this.UploadStudentList.Text = "Classes";
            // 
            // addClassToolStripMenuItem
            // 
            this.addClassToolStripMenuItem.Name = "addClassToolStripMenuItem";
            this.addClassToolStripMenuItem.Size = new System.Drawing.Size(233, 32);
            this.addClassToolStripMenuItem.Text = "Add Class";
            // 
            // viewAllClassesToolStripMenuItem
            // 
            this.viewAllClassesToolStripMenuItem.Name = "viewAllClassesToolStripMenuItem";
            this.viewAllClassesToolStripMenuItem.Size = new System.Drawing.Size(233, 32);
            this.viewAllClassesToolStripMenuItem.Text = "View All Classes";
            // 
            // staffToolStripMenuItem
            // 
            this.staffToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewStaffToolStripMenuItem,
            this.viewAllStaffToolStripMenuItem});
            this.staffToolStripMenuItem.Name = "staffToolStripMenuItem";
            this.staffToolStripMenuItem.Size = new System.Drawing.Size(65, 32);
            this.staffToolStripMenuItem.Text = "Staff";
            // 
            // addNewStaffToolStripMenuItem
            // 
            this.addNewStaffToolStripMenuItem.Name = "addNewStaffToolStripMenuItem";
            this.addNewStaffToolStripMenuItem.Size = new System.Drawing.Size(224, 32);
            this.addNewStaffToolStripMenuItem.Text = "Add New Staff";
            this.addNewStaffToolStripMenuItem.Click += new System.EventHandler(this.addNewStaffToolStripMenuItem_Click);
            // 
            // viewAllStaffToolStripMenuItem
            // 
            this.viewAllStaffToolStripMenuItem.Name = "viewAllStaffToolStripMenuItem";
            this.viewAllStaffToolStripMenuItem.Size = new System.Drawing.Size(224, 32);
            this.viewAllStaffToolStripMenuItem.Text = "View All Staff";
            this.viewAllStaffToolStripMenuItem.Click += new System.EventHandler(this.viewAllStaffToolStripMenuItem_Click);
            // 
            // rolesToolStripMenuItem
            // 
            this.rolesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewRoleToolStripMenuItem,
            this.viewRolesToolStripMenuItem});
            this.rolesToolStripMenuItem.Name = "rolesToolStripMenuItem";
            this.rolesToolStripMenuItem.Size = new System.Drawing.Size(72, 32);
            this.rolesToolStripMenuItem.Text = "Roles";
            // 
            // addNewRoleToolStripMenuItem
            // 
            this.addNewRoleToolStripMenuItem.Name = "addNewRoleToolStripMenuItem";
            this.addNewRoleToolStripMenuItem.Size = new System.Drawing.Size(224, 32);
            this.addNewRoleToolStripMenuItem.Text = "Add New Role";
            // 
            // viewRolesToolStripMenuItem
            // 
            this.viewRolesToolStripMenuItem.Name = "viewRolesToolStripMenuItem";
            this.viewRolesToolStripMenuItem.Size = new System.Drawing.Size(224, 32);
            this.viewRolesToolStripMenuItem.Text = "View Roles";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.makeNewFeePaymentToolStripMenuItem,
            this.seeAllPaymentRecordsToolStripMenuItem,
            this.checkStudentPaymentStatementRecordsToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(136, 32);
            this.toolStripMenuItem1.Text = "Fee Payment";
            // 
            // makeNewFeePaymentToolStripMenuItem
            // 
            this.makeNewFeePaymentToolStripMenuItem.Name = "makeNewFeePaymentToolStripMenuItem";
            this.makeNewFeePaymentToolStripMenuItem.Size = new System.Drawing.Size(471, 32);
            this.makeNewFeePaymentToolStripMenuItem.Text = "Make New Fee Payment";
            // 
            // seeAllPaymentRecordsToolStripMenuItem
            // 
            this.seeAllPaymentRecordsToolStripMenuItem.Name = "seeAllPaymentRecordsToolStripMenuItem";
            this.seeAllPaymentRecordsToolStripMenuItem.Size = new System.Drawing.Size(471, 32);
            this.seeAllPaymentRecordsToolStripMenuItem.Text = "See All Payment Records";
            // 
            // checkStudentPaymentStatementRecordsToolStripMenuItem
            // 
            this.checkStudentPaymentStatementRecordsToolStripMenuItem.Name = "checkStudentPaymentStatementRecordsToolStripMenuItem";
            this.checkStudentPaymentStatementRecordsToolStripMenuItem.Size = new System.Drawing.Size(471, 32);
            this.checkStudentPaymentStatementRecordsToolStripMenuItem.Text = "Check Student Payment Statement Records";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.checkStudentAccountToolStripMenuItem,
            this.viewPaymentStatementsToolStripMenuItem,
            this.assignStructuresToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(179, 32);
            this.toolStripMenuItem2.Text = "Student Accounts";
            // 
            // checkStudentAccountToolStripMenuItem
            // 
            this.checkStudentAccountToolStripMenuItem.Name = "checkStudentAccountToolStripMenuItem";
            this.checkStudentAccountToolStripMenuItem.Size = new System.Drawing.Size(321, 32);
            this.checkStudentAccountToolStripMenuItem.Text = "Check Student Account";
            // 
            // viewPaymentStatementsToolStripMenuItem
            // 
            this.viewPaymentStatementsToolStripMenuItem.Name = "viewPaymentStatementsToolStripMenuItem";
            this.viewPaymentStatementsToolStripMenuItem.Size = new System.Drawing.Size(321, 32);
            this.viewPaymentStatementsToolStripMenuItem.Text = "View Payment Statements";
            // 
            // assignStructuresToolStripMenuItem
            // 
            this.assignStructuresToolStripMenuItem.Name = "assignStructuresToolStripMenuItem";
            this.assignStructuresToolStripMenuItem.Size = new System.Drawing.Size(321, 32);
            this.assignStructuresToolStripMenuItem.Text = "Assign Structures";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewFeeStructureToolStripMenuItem,
            this.updateExistingStructuresToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(148, 32);
            this.toolStripMenuItem3.Text = "Fee Structures";
            // 
            // addNewFeeStructureToolStripMenuItem
            // 
            this.addNewFeeStructureToolStripMenuItem.Name = "addNewFeeStructureToolStripMenuItem";
            this.addNewFeeStructureToolStripMenuItem.Size = new System.Drawing.Size(327, 32);
            this.addNewFeeStructureToolStripMenuItem.Text = "Add New Fee Structure";
            // 
            // updateExistingStructuresToolStripMenuItem
            // 
            this.updateExistingStructuresToolStripMenuItem.Name = "updateExistingStructuresToolStripMenuItem";
            this.updateExistingStructuresToolStripMenuItem.Size = new System.Drawing.Size(327, 32);
            this.updateExistingStructuresToolStripMenuItem.Text = "Update Existing Structures";
            // 
            // recordsToolStripMenuItem
            // 
            this.recordsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewPaymentRecordsToolStripMenuItem,
            this.viewPhysicalDeliveryRecordsToolStripMenuItem,
            this.viewPaymentByClassToolStripMenuItem,
            this.checkBalancesToolStripMenuItem});
            this.recordsToolStripMenuItem.Name = "recordsToolStripMenuItem";
            this.recordsToolStripMenuItem.Size = new System.Drawing.Size(95, 32);
            this.recordsToolStripMenuItem.Text = "Records";
            // 
            // viewPaymentRecordsToolStripMenuItem
            // 
            this.viewPaymentRecordsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bankSlipsToolStripMenuItem,
            this.mpesaToolStripMenuItem,
            this.cashToolStripMenuItem});
            this.viewPaymentRecordsToolStripMenuItem.Name = "viewPaymentRecordsToolStripMenuItem";
            this.viewPaymentRecordsToolStripMenuItem.Size = new System.Drawing.Size(361, 32);
            this.viewPaymentRecordsToolStripMenuItem.Text = "View Payment Records";
            // 
            // bankSlipsToolStripMenuItem
            // 
            this.bankSlipsToolStripMenuItem.Name = "bankSlipsToolStripMenuItem";
            this.bankSlipsToolStripMenuItem.Size = new System.Drawing.Size(186, 32);
            this.bankSlipsToolStripMenuItem.Text = "Bank Slips";
            // 
            // mpesaToolStripMenuItem
            // 
            this.mpesaToolStripMenuItem.Name = "mpesaToolStripMenuItem";
            this.mpesaToolStripMenuItem.Size = new System.Drawing.Size(186, 32);
            this.mpesaToolStripMenuItem.Text = "Mpesa";
            // 
            // cashToolStripMenuItem
            // 
            this.cashToolStripMenuItem.Name = "cashToolStripMenuItem";
            this.cashToolStripMenuItem.Size = new System.Drawing.Size(186, 32);
            this.cashToolStripMenuItem.Text = "Cash";
            // 
            // viewPhysicalDeliveryRecordsToolStripMenuItem
            // 
            this.viewPhysicalDeliveryRecordsToolStripMenuItem.Name = "viewPhysicalDeliveryRecordsToolStripMenuItem";
            this.viewPhysicalDeliveryRecordsToolStripMenuItem.Size = new System.Drawing.Size(361, 32);
            this.viewPhysicalDeliveryRecordsToolStripMenuItem.Text = "View Physical delivery Records";
            // 
            // viewPaymentByClassToolStripMenuItem
            // 
            this.viewPaymentByClassToolStripMenuItem.Name = "viewPaymentByClassToolStripMenuItem";
            this.viewPaymentByClassToolStripMenuItem.Size = new System.Drawing.Size(361, 32);
            this.viewPaymentByClassToolStripMenuItem.Text = "View Payment By Class";
            // 
            // checkBalancesToolStripMenuItem
            // 
            this.checkBalancesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.byClassToolStripMenuItem,
            this.allFeeBalancesToolStripMenuItem,
            this.physicalDeliveryBalancesToolStripMenuItem,
            this.checkForPayrollToolStripMenuItem});
            this.checkBalancesToolStripMenuItem.Name = "checkBalancesToolStripMenuItem";
            this.checkBalancesToolStripMenuItem.Size = new System.Drawing.Size(361, 32);
            this.checkBalancesToolStripMenuItem.Text = "Check Balances";
            // 
            // byClassToolStripMenuItem
            // 
            this.byClassToolStripMenuItem.Name = "byClassToolStripMenuItem";
            this.byClassToolStripMenuItem.Size = new System.Drawing.Size(322, 32);
            this.byClassToolStripMenuItem.Text = "By Class";
            // 
            // allFeeBalancesToolStripMenuItem
            // 
            this.allFeeBalancesToolStripMenuItem.Name = "allFeeBalancesToolStripMenuItem";
            this.allFeeBalancesToolStripMenuItem.Size = new System.Drawing.Size(322, 32);
            this.allFeeBalancesToolStripMenuItem.Text = "All Fee Balances";
            // 
            // physicalDeliveryBalancesToolStripMenuItem
            // 
            this.physicalDeliveryBalancesToolStripMenuItem.Name = "physicalDeliveryBalancesToolStripMenuItem";
            this.physicalDeliveryBalancesToolStripMenuItem.Size = new System.Drawing.Size(322, 32);
            this.physicalDeliveryBalancesToolStripMenuItem.Text = "Physical Delivery Balances";
            // 
            // checkForPayrollToolStripMenuItem
            // 
            this.checkForPayrollToolStripMenuItem.Name = "checkForPayrollToolStripMenuItem";
            this.checkForPayrollToolStripMenuItem.Size = new System.Drawing.Size(322, 32);
            this.checkForPayrollToolStripMenuItem.Text = "Procurement Records";
            // 
            // transportToolStripMenuItem
            // 
            this.transportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewTransportRoutesToolStripMenuItem,
            this.viewListOfTransportToolStripMenuItem});
            this.transportToolStripMenuItem.Name = "transportToolStripMenuItem";
            this.transportToolStripMenuItem.Size = new System.Drawing.Size(108, 32);
            this.transportToolStripMenuItem.Text = "Transport";
            // 
            // addNewTransportRoutesToolStripMenuItem
            // 
            this.addNewTransportRoutesToolStripMenuItem.Name = "addNewTransportRoutesToolStripMenuItem";
            this.addNewTransportRoutesToolStripMenuItem.Size = new System.Drawing.Size(338, 32);
            this.addNewTransportRoutesToolStripMenuItem.Text = "Add New Transport Routes";
            // 
            // viewListOfTransportToolStripMenuItem
            // 
            this.viewListOfTransportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.byClassToolStripMenuItem1,
            this.byRouteToolStripMenuItem});
            this.viewListOfTransportToolStripMenuItem.Name = "viewListOfTransportToolStripMenuItem";
            this.viewListOfTransportToolStripMenuItem.Size = new System.Drawing.Size(338, 32);
            this.viewListOfTransportToolStripMenuItem.Text = "View List Of Transport Users";
            // 
            // byClassToolStripMenuItem1
            // 
            this.byClassToolStripMenuItem1.Name = "byClassToolStripMenuItem1";
            this.byClassToolStripMenuItem1.Size = new System.Drawing.Size(175, 32);
            this.byClassToolStripMenuItem1.Text = "By Class";
            // 
            // byRouteToolStripMenuItem
            // 
            this.byRouteToolStripMenuItem.Name = "byRouteToolStripMenuItem";
            this.byRouteToolStripMenuItem.Size = new System.Drawing.Size(175, 32);
            this.byRouteToolStripMenuItem.Text = "By Route";
            // 
            // physicalStructuresToolStripMenuItem
            // 
            this.physicalStructuresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addPhysicalStructureToolStripMenuItem,
            this.viewPhysucalStructuresToolStripMenuItem,
            this.assignToStudentsToolStripMenuItem});
            this.physicalStructuresToolStripMenuItem.Name = "physicalStructuresToolStripMenuItem";
            this.physicalStructuresToolStripMenuItem.Size = new System.Drawing.Size(187, 32);
            this.physicalStructuresToolStripMenuItem.Text = "Physical Structures";
            // 
            // addPhysicalStructureToolStripMenuItem
            // 
            this.addPhysicalStructureToolStripMenuItem.Name = "addPhysicalStructureToolStripMenuItem";
            this.addPhysicalStructureToolStripMenuItem.Size = new System.Drawing.Size(305, 32);
            this.addPhysicalStructureToolStripMenuItem.Text = "Add Physical Structure";
            // 
            // viewPhysucalStructuresToolStripMenuItem
            // 
            this.viewPhysucalStructuresToolStripMenuItem.Name = "viewPhysucalStructuresToolStripMenuItem";
            this.viewPhysucalStructuresToolStripMenuItem.Size = new System.Drawing.Size(305, 32);
            this.viewPhysucalStructuresToolStripMenuItem.Text = "View Physical Structures";
            // 
            // assignToStudentsToolStripMenuItem
            // 
            this.assignToStudentsToolStripMenuItem.Name = "assignToStudentsToolStripMenuItem";
            this.assignToStudentsToolStripMenuItem.Size = new System.Drawing.Size(305, 32);
            this.assignToStudentsToolStripMenuItem.Text = "Assign To Students";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(97, 32);
            this.logOutToolStripMenuItem.Text = "Log Out";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.pictureBox9);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(183, 164);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(1288, 396);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Accounting Operations";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label24.Location = new System.Drawing.Point(748, 325);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(105, 20);
            this.label24.TabIndex = 17;
            this.label24.Text = "Procurement";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DarkRed;
            this.label16.Location = new System.Drawing.Point(1153, 44);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 21);
            this.label16.TabIndex = 16;
            this.label16.Text = "6";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label11.Location = new System.Drawing.Point(395, 325);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 20);
            this.label11.TabIndex = 15;
            this.label11.Text = "Physical Delivery";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label10.Location = new System.Drawing.Point(53, 325);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(160, 20);
            this.label10.TabIndex = 14;
            this.label10.Text = "Transport Payments";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label9.Location = new System.Drawing.Point(1035, 144);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(155, 20);
            this.label9.TabIndex = 13;
            this.label9.Text = "Incoming Payments";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label8.Location = new System.Drawing.Point(769, 144);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "Records";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label7.Location = new System.Drawing.Point(383, 144);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(164, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "Student Account Info";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label6.Location = new System.Drawing.Point(75, 144);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Make Payment";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(1051, 220);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(133, 101);
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(735, 220);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(133, 101);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(399, 220);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(133, 101);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox8.TabIndex = 5;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(76, 220);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(133, 101);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox9.TabIndex = 4;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(1051, 44);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(133, 96);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(735, 44);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(133, 96);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(399, 44);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(133, 96);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(76, 44);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(133, 96);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.pictureBox14);
            this.groupBox2.Controls.Add(this.pictureBox13);
            this.groupBox2.Controls.Add(this.pictureBox12);
            this.groupBox2.Controls.Add(this.pictureBox11);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(183, 565);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(1288, 342);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Registration Operations";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label15.Location = new System.Drawing.Point(1057, 224);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 20);
            this.label15.TabIndex = 19;
            this.label15.Text = "System Users";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label14.Location = new System.Drawing.Point(769, 224);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 20);
            this.label14.TabIndex = 18;
            this.label14.Text = "Roles";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label13.Location = new System.Drawing.Point(425, 224);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 20);
            this.label13.TabIndex = 17;
            this.label13.Text = "Classes";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label12.Location = new System.Drawing.Point(72, 224);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(124, 20);
            this.label12.TabIndex = 16;
            this.label12.Text = "Manage People";
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(1051, 119);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(133, 101);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox14.TabIndex = 8;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(735, 119);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(133, 101);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox13.TabIndex = 7;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(399, 119);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(133, 101);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox12.TabIndex = 6;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(76, 119);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(133, 101);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox11.TabIndex = 5;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripLabel2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(173, 949);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(170, 32);
            this.toolStripLabel1.Text = "Soma Suite";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(170, 32);
            this.toolStripLabel2.Text = "Desktop Client";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 122);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(308, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(308, 49);
            this.label1.TabIndex = 7;
            this.label1.Text = "Main Dashboard";
            // 
            // IncomingInfo
            // 
            this.IncomingInfo.Controls.Add(this.button1);
            this.IncomingInfo.Controls.Add(this.label22);
            this.IncomingInfo.Controls.Add(this.label21);
            this.IncomingInfo.Controls.Add(this.label20);
            this.IncomingInfo.Controls.Add(this.label19);
            this.IncomingInfo.Controls.Add(this.label18);
            this.IncomingInfo.Controls.Add(this.label17);
            this.IncomingInfo.Controls.Add(this.label5);
            this.IncomingInfo.Controls.Add(this.label4);
            this.IncomingInfo.Controls.Add(this.label3);
            this.IncomingInfo.Controls.Add(this.label2);
            this.IncomingInfo.Controls.Add(this.pictureBox10);
            this.IncomingInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IncomingInfo.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.IncomingInfo.Location = new System.Drawing.Point(1477, 164);
            this.IncomingInfo.Margin = new System.Windows.Forms.Padding(4);
            this.IncomingInfo.Name = "IncomingInfo";
            this.IncomingInfo.Padding = new System.Windows.Forms.Padding(4);
            this.IncomingInfo.Size = new System.Drawing.Size(372, 742);
            this.IncomingInfo.TabIndex = 8;
            this.IncomingInfo.TabStop = false;
            this.IncomingInfo.Text = "User Profile ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.Location = new System.Drawing.Point(40, 602);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(308, 55);
            this.button1.TabIndex = 19;
            this.button1.Text = "Edit Profile";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label22.Location = new System.Drawing.Point(81, 500);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 20);
            this.label22.TabIndex = 18;
            this.label22.Text = "label22";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label21.Location = new System.Drawing.Point(36, 464);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 20);
            this.label21.TabIndex = 17;
            this.label21.Text = "label21";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label20.Location = new System.Drawing.Point(81, 432);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(122, 20);
            this.label20.TabIndex = 16;
            this.label20.Text = "Administrator";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label19.Location = new System.Drawing.Point(36, 401);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 20);
            this.label19.TabIndex = 15;
            this.label19.Text = "Role";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label18.Location = new System.Drawing.Point(81, 377);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(89, 20);
            this.label18.TabIndex = 14;
            this.label18.Text = "30499569";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label17.Location = new System.Drawing.Point(36, 341);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 20);
            this.label17.TabIndex = 13;
            this.label17.Text = "ID Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label5.Location = new System.Drawing.Point(81, 302);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(212, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "LagattAlpha@gmail.com";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(36, 267);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "Email Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(81, 235);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Alpha Lagatt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(36, 204);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "User Name ";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(85, 26);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(192, 151);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox10.TabIndex = 8;
            this.pictureBox10.TabStop = false;
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(1915, 164);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 742);
            this.vScrollBar1.TabIndex = 9;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.DarkCyan;
            this.label23.Location = new System.Drawing.Point(567, 923);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(570, 20);
            this.label23.TabIndex = 10;
            this.label23.Text = "Developed and managed by NameSpace Labs SomaSuite.inc @ 2020-2021";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1924, 949);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.vScrollBar1);
            this.Controls.Add(this.IncomingInfo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Students);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Students.ResumeLayout(false);
            this.Students.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.IncomingInfo.ResumeLayout(false);
            this.IncomingInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip Students;
        private System.Windows.Forms.ToolStripMenuItem AddStudent;
        private System.Windows.Forms.ToolStripMenuItem addStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewStudentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uploadStudentListsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ViewAllStudents;
        private System.Windows.Forms.ToolStripMenuItem addParentGuardianToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem assignParentGuardianToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllParentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applyFiltersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentAdmissionNumbersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nationalIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem UploadStudentList;
        private System.Windows.Forms.ToolStripMenuItem addClassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllClassesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem staffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewStaffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllStaffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rolesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewRoleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewRolesToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem makeNewFeePaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seeAllPaymentRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkStudentPaymentStatementRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem checkStudentAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPaymentStatementsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem assignStructuresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem addNewFeeStructureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateExistingStructuresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem physicalStructuresToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem viewPaymentRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankSlipsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mpesaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cashToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPhysicalDeliveryRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPaymentByClassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkBalancesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem byClassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allFeeBalancesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem physicalDeliveryBalancesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkForPayrollToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewTransportRoutesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewListOfTransportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem byClassToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem byRouteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addPhysicalStructureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPhysucalStructuresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem assignToStudentsToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox IncomingInfo;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
    }
}

