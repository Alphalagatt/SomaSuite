﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomaSuiteDesktopClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

           // LogInForm mylogin = new LogInForm();
           // mylogin.ShowDialog();
            

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MakePaymentForm paymentForm = new MakePaymentForm();
            paymentForm.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            StudentAccountForm accountForm = new StudentAccountForm();
            accountForm.ShowDialog();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            RecordForm recordForm = new RecordForm();
            recordForm.ShowDialog();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            IncomingPaymentsForm incoming = new IncomingPaymentsForm();
            incoming.ShowDialog();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            TransportPaymentForm transportPayment = new TransportPaymentForm();
            transportPayment.ShowDialog();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            PhysicalDeliveryForm physicalDelivery = new PhysicalDeliveryForm();
            physicalDelivery.ShowDialog();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            //people form
            PeopleNavForm peopleNav = new PeopleNavForm();
            peopleNav.ShowDialog();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            //classes form
            ClassesForm classes = new ClassesForm();
            classes.ShowDialog();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            //roles form
            RolesForm roles = new RolesForm();
            roles.ShowDialog();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            //users form
            UserManagementForm userManagement = new UserManagementForm();
            userManagement.ShowDialog();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            
        }

        private void viewAllStaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AllStaff allStaff = new AllStaff();
            allStaff.ShowDialog();
        }

        private void addNewStaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewStaffForm newStaff = new NewStaffForm();
            newStaff.ShowDialog();

        }
    }
}
