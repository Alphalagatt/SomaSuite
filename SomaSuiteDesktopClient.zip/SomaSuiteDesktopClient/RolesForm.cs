﻿using Newtonsoft.Json;
using SomaSuiteDesktopClient.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomaSuiteDesktopClient
{
    public partial class RolesForm : Form
    {
        public RolesForm()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            string postUrl = "https://localhost:44312/api/Role";

            Role myRole = await postRole(postUrl,client);

            MessageBox.Show("New Role Successfully Added. \nRole Name: " + myRole.RoleName + "\n Description: " + myRole.Description,"SomaSuite inc");

            textBox1.Text = null;
            textBox6.Text = null;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        //method to save to the api


        async Task<Role> postRole(string url, HttpClient client)
        {
            
            
            Role newRole = new Role();
            newRole.RoleName = textBox1.Text;
            newRole.Description = textBox6.Text;

            await client.PostAsJsonAsync<Role>(url,newRole);

            return newRole;
        }




    }
}
