﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomaSuiteDesktopClient.Models
{
    class RoleStaff
    {
        public int RolesRoleId { get; set; }
        public string StaffsStaffId { get; set; }

    }
}
