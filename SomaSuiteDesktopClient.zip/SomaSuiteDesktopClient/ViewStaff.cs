﻿using Newtonsoft.Json;
using SomaSuiteDesktopClient.Conts;
using SomaSuiteDesktopClient.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomaSuiteDesktopClient
{
    public partial class ViewStaff : Form
    {
        public ViewStaff()
        {
            InitializeComponent();
        }

        string stID;
        public ViewStaff(string StaffID)
        {
            InitializeComponent();

             stID = StaffID;

        }

        private void ViewStaff_Load(object sender, EventArgs e)
        {
            try
            {
                var client = new RestClient() { EndPoint = "https://localhost:44312/api/Staff/"+stID, Method = "Get" };
                var result = client.MakeRequest();

                Staff Staffs = new Staff();

                Staffs = JsonConvert.DeserializeObject<Staff>(result);



                //myTable.Add(myStaff);
                //dataGridView1.Rows.Add(myStaff.Photo,myStaff.StaffID, myStaff.FullName, myStaff.NationalIDNo);
                //staffBindingSource.Add(myStaff);

                label3.Text = Staffs.StaffID;
                label5.Text = Staffs.FullName;
                label18.Text = Staffs.NationalIDNo;
                

                

            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Could not be established. Please check your internet connection. \n" + ex);
            }
        }
    }
}
