﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomaSuiteDesktopClient
{
    public partial class MakePaymentForm : Form
    {
        public MakePaymentForm()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox2.Text == "Mpesa")
            {
                MpesaPaymentsForm myform = new MpesaPaymentsForm();
                myform.ShowDialog();

            }

        }
    }
}
